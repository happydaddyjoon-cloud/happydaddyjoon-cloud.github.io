felizpapa Sans 공식 배포판 - Official Font Family

목적
- 전문 폰트 배포용 구성입니다.
- 글꼴 목록에는 주로 "felizpapa Sans" 하나의 패밀리로 보입니다.
- 프로그램의 굵기/스타일 기능으로 Light / Regular / Bold를 사용합니다.

설치 방법
1. 압축을 완전히 풉니다.
2. INSTALL_OFFICIAL_FONT_FAMILY.cmd 를 더블클릭합니다.
3. 관리자 권한 창이 뜨면 "예"를 누릅니다.
4. 설치 후 Excel, Word, PowerPoint, 한글(HWP)을 모두 닫았다가 다시 엽니다.
5. 글꼴 입력칸에 "felizpapa Sans"를 직접 입력합니다.

설치되는 구성
- felizpapa Sans Light
- felizpapa Sans Regular
- felizpapa Sans Bold

권장 사용
- 공식 배포, 브랜드 문서, PDF, 웹/디자인 작업, 장기 보관 문서

주의
- 이 패키지는 폰트 파일 자체를 포함하지 않습니다.
- 설치 시 공식 Noto Sans CJK KR 오픈폰트를 다운로드하고, felizpapa Sans 이름으로 재구성하여 설치합니다.
- 설치에는 인터넷, Python, 관리자 권한이 필요합니다.

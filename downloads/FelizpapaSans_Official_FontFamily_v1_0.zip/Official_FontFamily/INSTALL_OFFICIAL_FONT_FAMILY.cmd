@echo off
chcp 65001 >nul
title felizpapa Sans Official Font Family Installer
cd /d "%~dp0"
echo ==========================================================
echo  felizpapa Sans - OFFICIAL FONT FAMILY installer
echo ==========================================================
echo.
echo This version appears mainly as one font family:
echo   felizpapa Sans
echo Styles are Light / Regular / Bold inside the same family.
echo.
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Requesting administrator permission...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
where py >nul 2>&1
if "%errorlevel%"=="0" (set "PY_CMD=py -3") else (set "PY_CMD=python")
echo [1/3] Installing/checking fontTools...
%PY_CMD% -m pip install --user --upgrade fonttools brotli
if not "%errorlevel%"=="0" (echo ERROR: fontTools install failed.& pause& exit /b 1)
echo [2/3] Installing official font family...
%PY_CMD% "%~dp0install_felizpapa_v6.py" --mode family --action install
if not "%errorlevel%"=="0" (echo ERROR: install failed. See install_log_family.txt& pause& exit /b 1)
echo [3/3] Done.
echo.
echo Close and reopen Excel/Word/PowerPoint/HWP.
echo Font name: felizpapa Sans
echo.
pause

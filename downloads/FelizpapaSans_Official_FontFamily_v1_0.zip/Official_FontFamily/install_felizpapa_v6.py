# -*- coding: utf-8 -*-
"""
felizpapa Sans V6 installer
Modes:
  --mode family   : professional font family, shown mainly as 'felizpapa Sans'
  --mode separate : practical separated weights, shown as 'felizpapa Sans Light/Regular/Bold'

This script downloads open source Noto Sans CJK KR OTFs, renames internal font names,
and installs them into C:\\Windows\\Fonts with HKLM registry entries for Office/Excel visibility.
"""
from __future__ import annotations

import argparse
import ctypes
import os
import shutil
import sys
import time
import urllib.request
import winreg
from pathlib import Path

try:
    from fontTools.ttLib import TTFont
except Exception as exc:
    print("ERROR: fontTools is not installed:", exc)
    sys.exit(2)

SCRIPT_DIR = Path(__file__).resolve().parent
REG_PATH = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"

FONT_URLS = {
    "Light": "https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/Korean/NotoSansCJKkr-Light.otf",
    "Regular": "https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/Korean/NotoSansCJKkr-Regular.otf",
    "Bold": "https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/Korean/NotoSansCJKkr-Bold.otf",
}
WEIGHTS = {"Light": 300, "Regular": 400, "Bold": 700}


def get_log_path(mode: str) -> Path:
    return SCRIPT_DIR / f"install_log_{mode}.txt"


def log(mode: str, msg: str) -> None:
    text = f"[{time.strftime('%H:%M:%S')}] {msg}"
    print(text)
    with get_log_path(mode).open("a", encoding="utf-8") as f:
        f.write(text + "\n")


def is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def set_name_record(name_table, name_id: int, value: str) -> None:
    name_table.names = [n for n in name_table.names if n.nameID != name_id]
    # Windows Unicode English
    name_table.setName(value, name_id, 3, 1, 0x409)
    name_table.setName(value, name_id, 3, 10, 0x409)
    # Windows Unicode Korean
    name_table.setName(value, name_id, 3, 1, 0x412)
    name_table.setName(value, name_id, 3, 10, 0x412)
    # Macintosh / Unicode fallback
    name_table.setName(value, name_id, 1, 0, 0)
    name_table.setName(value, name_id, 0, 3, 0)


def family_and_names(mode: str, style: str) -> dict[str, str]:
    if mode == "family":
        family = "felizpapa Sans"
        subfamily = style
        full = f"{family} {style}"
        ps = f"felizpapaSans-{style}"
        reg_name = f"{full} (OpenType)"
        file_name = f"felizpapaSans-{style}.otf"
        cleanup_prefixes = ["felizpapa"]
    elif mode == "separate":
        family = f"felizpapa Sans {style}"
        subfamily = "Regular"
        full = family
        ps = f"felizpapaSans{style}-Regular"
        reg_name = f"{full} (OpenType)"
        file_name = f"felizpapaSans-{style}-Separate.otf"
        cleanup_prefixes = ["felizpapa"]
    else:
        raise ValueError(mode)
    return {
        "family": family,
        "subfamily": subfamily,
        "full": full,
        "ps": ps,
        "reg_name": reg_name,
        "file_name": file_name,
        "cleanup_prefixes": "|".join(cleanup_prefixes),
    }


def delete_value_if_contains(root, needle: str, mode: str) -> None:
    try:
        with winreg.OpenKey(root, REG_PATH, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as key:
            names = []
            i = 0
            while True:
                try:
                    name, value, typ = winreg.EnumValue(key, i)
                    if needle.lower() in name.lower() or needle.lower() in str(value).lower():
                        names.append(name)
                    i += 1
                except OSError:
                    break
            for name in names:
                try:
                    winreg.DeleteValue(key, name)
                    log(mode, f"Deleted registry value: {name}")
                except OSError:
                    pass
    except OSError:
        return


def cleanup(mode: str, font_dir: Path) -> None:
    log(mode, "Cleaning old felizpapa font files and registry entries")
    delete_value_if_contains(winreg.HKEY_LOCAL_MACHINE, "felizpapa", mode)
    delete_value_if_contains(winreg.HKEY_CURRENT_USER, "felizpapa", mode)

    folders = [font_dir, Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts"]
    for folder in folders:
        if not folder.exists():
            continue
        for pattern in ["felizpapa*.otf", "felizpapa*.ttf", "felizpapaSans*.otf", "felizpapaSans*.ttf"]:
            for p in folder.glob(pattern):
                try:
                    p.unlink()
                    log(mode, f"Deleted old font file: {p}")
                except Exception as exc:
                    log(mode, f"WARN: could not delete {p}: {exc}")


def download(mode: str, url: str, dest: Path) -> None:
    log(mode, f"Downloading {dest.name}")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=120) as r, dest.open("wb") as f:
        shutil.copyfileobj(r, f)
    if dest.stat().st_size < 1000000:
        raise RuntimeError(f"Downloaded file too small: {dest}")


def rename_font(mode: str, src: Path, dest: Path, style: str) -> None:
    names = family_and_names(mode, style)
    family = names["family"]
    subfamily = names["subfamily"]
    full = names["full"]
    ps = names["ps"]
    log(mode, f"Renaming internal font names: {full}")

    font = TTFont(src)
    nt = font["name"]
    record_values = {
        0: "Copyright (c) Noto Project Authors. Renamed as felizpapa Sans for permitted use under the SIL Open Font License.",
        1: family,
        2: subfamily,
        3: f"{ps};V6;{int(time.time())}",
        4: full,
        5: "Version 6.000",
        6: ps,
        16: family,
        17: subfamily,
        18: full,
        21: family,
        22: subfamily,
    }
    for nid, val in record_values.items():
        set_name_record(nt, nid, val)

    if "OS/2" in font:
        os2 = font["OS/2"]
        os2.usWeightClass = WEIGHTS[style]
        try:
            # Regular bit only for non-Bold/Italic regular style. For separate mode every family is a Regular style.
            if mode == "separate" or style == "Regular":
                os2.fsSelection |= 0x40
            else:
                os2.fsSelection &= ~0x40
            # Bold bit for Bold style in family mode.
            if style == "Bold" and mode == "family":
                os2.fsSelection |= 0x20
        except Exception:
            pass

    if "head" in font:
        font["head"].macStyle = 1 if (mode == "family" and style == "Bold") else 0

    if "CFF " in font:
        cff = font["CFF "].cff
        cff.fontNames = [ps]
        top = cff.topDictIndex[0]
        for attr, val in {
            "FullName": full,
            "FamilyName": family,
            "Weight": style,
            "version": "6.000",
            "Notice": "Based on Noto Sans CJK KR under SIL Open Font License. Renamed for felizpapa Sans distribution.",
            "Copyright": "Copyright (c) Noto Project Authors. Modified/renamed as felizpapa Sans.",
        }.items():
            try:
                setattr(top, attr, val)
            except Exception:
                pass
        try:
            top.CIDFontName = ps
        except Exception:
            pass

    font.save(dest)
    log(mode, f"Created renamed font: {dest.name}")


def add_registry_hklm(mode: str, style: str, file_name: str) -> None:
    reg_name = family_and_names(mode, style)["reg_name"]
    with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, REG_PATH, 0, winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as key:
        winreg.SetValueEx(key, reg_name, 0, winreg.REG_SZ, file_name)
    log(mode, f"Registered HKLM font: {reg_name} = {file_name}")


def add_font_resource(mode: str, path: Path) -> None:
    added = ctypes.windll.gdi32.AddFontResourceW(str(path))
    log(mode, f"AddFontResourceW returned {added} for {path.name}")


def broadcast_font_change(mode: str) -> None:
    HWND_BROADCAST = 0xFFFF
    WM_FONTCHANGE = 0x001D
    SMTO_ABORTIFHUNG = 0x0002
    result = ctypes.c_ulong()
    ctypes.windll.user32.SendMessageTimeoutW(HWND_BROADCAST, WM_FONTCHANGE, 0, 0, SMTO_ABORTIFHUNG, 5000, ctypes.byref(result))
    log(mode, "Broadcasted WM_FONTCHANGE")


def install(mode: str) -> int:
    get_log_path(mode).write_text(f"felizpapa Sans V6 {mode} install log\n", encoding="utf-8")
    log(mode, f"Starting install mode={mode}")
    if not is_admin():
        log(mode, "ERROR: Administrator permission is required")
        return 3

    font_dir = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
    work = SCRIPT_DIR / f"_work_v6_{mode}"
    work.mkdir(exist_ok=True)

    cleanup(mode, font_dir)

    for style, url in FONT_URLS.items():
        src = work / f"NotoSansCJKkr-{style}.otf"
        names = family_and_names(mode, style)
        out = work / names["file_name"]
        if not src.exists():
            download(mode, url, src)
        rename_font(mode, src, out, style)
        dest = font_dir / out.name
        shutil.copy2(out, dest)
        log(mode, f"Copied to Windows Fonts: {dest}")
        add_registry_hklm(mode, style, out.name)
        add_font_resource(mode, dest)

    broadcast_font_change(mode)
    if mode == "family":
        log(mode, "DONE - Professional family installed. Font list name: felizpapa Sans")
    else:
        log(mode, "DONE - Separate weights installed. Font list names: felizpapa Sans Light / Regular / Bold")
    return 0


def status(mode: str) -> int:
    print("=== felizpapa Sans Windows font status ===")
    font_dir = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
    for p in font_dir.glob("felizpapa*.otf"):
        print("FONT_FILE", p)
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, REG_PATH, 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
            i = 0
            while True:
                try:
                    name, value, typ = winreg.EnumValue(key, i)
                    if "felizpapa" in name.lower() or "felizpapa" in str(value).lower():
                        print("HKLM", name, "=", value)
                    i += 1
                except OSError:
                    break
    except Exception as exc:
        print("HKLM_READ_ERROR", exc)
    return 0


def uninstall(mode: str) -> int:
    get_log_path(mode).write_text(f"felizpapa Sans V6 {mode} uninstall log\n", encoding="utf-8")
    if not is_admin():
        print("ERROR: Administrator permission is required")
        return 3
    font_dir = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
    cleanup(mode, font_dir)
    broadcast_font_change(mode)
    log(mode, "DONE - removed felizpapa fonts")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["family", "separate"], required=True)
    parser.add_argument("--action", choices=["install", "status", "uninstall"], default="install")
    args = parser.parse_args()
    if args.action == "install":
        return install(args.mode)
    if args.action == "status":
        return status(args.mode)
    if args.action == "uninstall":
        return uninstall(args.mode)
    return 1

if __name__ == "__main__":
    raise SystemExit(main())

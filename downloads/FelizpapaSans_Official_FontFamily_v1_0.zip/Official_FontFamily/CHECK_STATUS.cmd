@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if "%errorlevel%"=="0" (set "PY_CMD=py -3") else (set "PY_CMD=python")
%PY_CMD% "%~dp0install_felizpapa_v6.py" --mode family --action status
pause
